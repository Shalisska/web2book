;$(document).ready(function() {
	var open = $('.header-menu__open');
	var menu = $('.header-menu');

	open.click(function(e) {
		e.preventDefault();
		menu.toggle();
	});

	$(document).click(function(e) {
		if(!menu.is(e.target)
			&& menu.has(e.target).length === 0
			&& !open.is(e.target)
			&& open.has(e.target).length === 0) {
				menu.hide();
		};
	});

	$(window).keydown(function(e) {
		if (e.keyCode==27) {
			menu.hide();
		}
	});
});